# описание узлов
knot_0000 = {'func_l': 'nul', 'count': 0, 'south': 0, 'east': 0, 'north': 0, 'west': 0}
knot_0001 = {'func_l': 'strex', 'count': 0, 'south': 0, 'east': 0, 'north': 0, 'west': 1}
knot_0100 = {'func_l': 'strex', 'count': 0, 'south': 0, 'east': 1, 'north': 0, 'west': 0}
knot_1001 = {'func_l': 'fncl', 'count': 0, 'south': 1, 'east': 0, 'north': 0, 'west': 1}
knot_1101 = {'func_l': 'knot', 'count': 0, 'south': 1, 'east': 1, 'north': 0, 'west': 1}
knot_1011 = {'func_l': 'knot', 'count': 0, 'south': 1, 'east': 0,'north': 1, 'west': 1}
knot_1111 = {'func_l': 'knot', 'count': 0, 'south': 1, 'east': 1, 'north': 1, 'west': 1}
knot_1100 = {'func_l': 'fncl', 'count': 0, 'south': 1, 'east': 1, 'north': 0, 'west': 0}
knot_1110 = {'func_l': 'knot', 'count': 0, 'south': 1, 'east': 1, 'north': 1, 'west': 0}
knot_0110 = {'func_l': 'fncl', 'count': 0, 'south': 0, 'east': 1, 'north': 1, 'west': 0}
knot_0111 = {'func_l': 'knot', 'count': 0, 'south': 0, 'east': 1, 'north': 1, 'west': 1}
knot_0011 = {'func_l': 'fncl', 'count': 0, 'south': 0, 'east': 0, 'north': 1, 'west': 1}
knot_0101 = {'func_l': 'fncl', 'count': 0, 'south': 0, 'east': 1, 'north': 0, 'west': 1}
knot_1010 = {'func_l': 'fncl', 'count': 0, 'south': 1, 'east': 0, 'north': 1, 'west': 0}
knot_0101r = {'func_l': 'g_res', 'resi': 0, 'south': 0, 'east': 1, 'north': 0, 'west': 1}
knot_1010r = {'func_l': 'v_res', 'resi': 0, 'south': 1, 'east': 0, 'north': 1, 'west': 0}
strt_x = 16
strt_y = 16
posit = ''
pre_pos = [0, 0]
pre_posit = {'func_l': 'nul', 'count': 0, 'south': 0, 'east': 0, 'north': 0, 'west': 0}
tru_posit = {'func_l': 'nul', 'count': 0, 'south': 0, 'east': 0, 'north': 0, 'west': 0}
last_posit = {'func_l': 'nul', 'count': 0, 'south': 0, 'east': 0, 'north': 0, 'west': 0}
sid_siet = ['rr', 'south', 'east', 'north', 'west']
last_pos = [0, 0]
tru_pos = [0, 0]
scnd_knot_pos = []
frst_knot_pos = []
sign_frst_knot = 0
frst_resit = ''
scnd_resit = ''
cnt_resi_s = 0
cnt_resi_p = 0
frst_res = [0, 0]
scnd_res = [0, 0]
# иниц поля
matrix = [[{}]*strt_y for i in range(strt_x)]
matrix1 = [[{}]*strt_y for i in range(1)]

import pygame
import sys
pygame.init()
screen = pygame.display.set_mode((900, 750))
clock = pygame.time.Clock()

matrix1[0][0] = knot_1100.copy()
matrix1[0][1] = knot_0110.copy()
matrix1[0][2] = knot_0011.copy()
matrix1[0][3] = knot_1001.copy()
matrix1[0][4] = knot_1110.copy()
matrix1[0][5] = knot_0111.copy()
matrix1[0][6] = knot_1011.copy()
matrix1[0][7] = knot_1101.copy()
matrix1[0][8] = knot_1111.copy()
matrix1[0][9] = knot_0101.copy()
matrix1[0][10] = knot_1010.copy()
matrix1[0][11] = knot_0101r.copy()
matrix1[0][12] = knot_1010r.copy()
matrix1[0][13] = knot_0001.copy()
matrix1[0][14] = knot_0100.copy()
matrix1[0][15] = knot_0000.copy()

# иниц заполнения поля
def fill_knots():
    matrix[4][0] = knot_0100.copy()

# поиск начального узла
def find_strt_knot(strt_x, strt_y):
    for n_y in range(0, strt_y):
        for n_x in range(0, strt_x):
            posit1 = matrix[n_x][n_y]
            if posit1 == knot_0100:
                break
        if posit1 == knot_0100:
            break
    if posit1 != knot_0100:
        err_strt_posit()
    for nn_y in range(0, strt_y):
        for nn_x in range(0, strt_x):
            posit2 = matrix[nn_x][nn_y]
            if posit2 == knot_0001:
                break
        if posit2 == knot_0001:
            break
    if posit1 != knot_0100 or posit2 != knot_0001:
        err_strt_posit()
    return n_x, n_y, nn_x, nn_y, posit1, posit2

# поиск начального узла модиф
def find_strt_knot_m(strt_x, strt_y):
    for n_y in range(0, strt_y):
        for n_x in range(0, strt_x):
            posit3 = matrix[n_x][n_y]
            if posit3 and posit3['func_l'] == 'strknot':
                break
        if posit3 and posit3['func_l'] == 'strknot':
            break
    return n_x, n_y, posit3

# иниц движения по узлам
def knot(n_x, n_y, posit):
    tru_pos = [n_x, n_y]
    inter = posit
    tru_posit = inter
    return tru_pos, tru_posit

# описание выходного вектора
def ex_strt_arr(ru_posit):
    if ru_posit['south'] == 1:
        ex_ar = 1
    if ru_posit['east'] == 1:
        ex_ar = 2
    if ru_posit['north'] == 1:
        ex_ar = 3
    if ru_posit['west'] == 1:
        ex_ar = 4
    return ex_ar

# описание входного вектора
def in_arr(ex_ar):
    if ex_ar == 1:
        in_ar = 3
    if ex_ar == 2:
        in_ar = 4
    if ex_ar == 3:
        in_ar = 1
    if ex_ar == 4:
        in_ar = 2
    return in_ar

# выход из узла
def ex_knot(ex_ar, in_ar, tru_pos, last_pos):
    inter = in_ar
    last_in_ar = inter
    a, b, c, d = 0, 0, 0, 0
    a = tru_pos[0]
    b = tru_pos[1]
    if ex_ar == 1:
        last_pos[0], last_pos[1] = a + 1, b
    if ex_ar == 2:
        last_pos[0], last_pos[1] = a, b + 1
    if ex_ar == 3:
        last_pos[0], last_pos[1] = a - 1, b
    if ex_ar == 4:
        last_pos[0], last_pos[1] = a, b - 1
    return last_in_ar, last_pos

#вход в узел
def in_knot(pre_pos, tru_pos, last_pos, pre_posit, tru_posit):
    inter3 = tru_pos.copy()
    pre_pos = inter3
    inter4 = last_pos.copy()
    tru_pos = inter4
    inter = tru_posit
    matrix[pre_pos[0]][pre_pos[1]] = inter
    inter1 = matrix[tru_pos[0]][tru_pos[1]]
    tru_posit = inter1
    inter2 = matrix[pre_pos[0]][pre_pos[1]]
    pre_posit = inter2
    return pre_pos, tru_pos, pre_posit, tru_posit, matrix[pre_pos[0]][pre_pos[1]]

#вход в узел 2
def in_knot2(pre_posit, tru_posit, sid_siet, in_ar):
    if pre_posit['func_l'] == 'strex':
        tru_posit['func_l'] = 'strknot'
        tru_posit[sid_siet[in_ar]] = -1
    return tru_posit

# проверка узел - проход по колл выходов
def pass_knot(any_posit, in_ar, sid_siet, sign_frst_knot, tru_pos, scnd_knot_pos):
    am_ex, b, sign_rep, d = 0, 0, 0, 0
    for i in ('south', 'east', 'north', 'west'):
        if any_posit[i] != 0:
            am_ex += 1
        if any_posit[i] == 2:
            d = 2
    if am_ex == 2:
        d = 1
    if am_ex >= 3:
        if d == 0:
            if sign_frst_knot == 2:
                sign_frst_knot = 0
            if sign_frst_knot == 1:
                sign_frst_knot = 2
                scnd_knot_pos = tru_pos.copy()
        if d == 2:
            sign_rep = 1
    return am_ex, b, sign_rep, d, any_posit, sign_frst_knot, scnd_knot_pos

#проверка возврата в узел
def cmbck_knot():
    pass

def del_knot(scnd_del_pos, frst_del_pos, delxpos):
    f = len(delxpos)
    for i in range(2, f):
        matrix[delxpos[i][0]][delxpos[i][1]] = {}
    for iii in ('south', 'east', 'north', 'west'):
        if matrix[scnd_del_pos[0]][scnd_del_pos[1]][iii] == 2:
                matrix[scnd_del_pos[0]][scnd_del_pos[1]][iii] = 0
        if matrix[frst_del_pos[0]][frst_del_pos[1]][iii] == 2:
                matrix[frst_del_pos[0]][frst_del_pos[1]][iii] = 1
    #print(scnd_del_pos, frst_del_pos, delxpos, f)

# проверка узел - проход по колл выходов 2
def pass_knot_m(any_posit):
    a = 0
    for i in ('south', 'east', 'north', 'west'):
        a += 1
        if any_posit[i] == -1:
            in_ar = a
            break
    return in_ar

# определение правила перехода
def rule_pass(am_ex, d, c, tru_posit, in_ar, sign_frst_knot):
    if am_ex > 2 and sign_frst_knot == 2 and d != 2:
        ex_ar = ag_arr(in_ar, tru_posit, sid_siet)
    if am_ex > 2 and sign_frst_knot == 1 and d != 2:
        ex_ar = on_arr(in_ar, tru_posit, sid_siet)
    if am_ex == 2:
        for z in range(4):
            x = in_ar // 4
            zx = in_ar + 1 - (4 * x)
            if tru_posit[sid_siet[zx]] == 1:
                ex_ar = zx
                break
            in_ar = zx
    return ex_ar

# описание перехода позиции
def last_f_pos():
    pass

# опис движ вектрора по правой
def on_arr(in_ar, tru_posit, sid_siet):
    for z in range(4):
        x = in_ar // 4
        zx = in_ar + 1 - (4 * x)
        if tru_posit[sid_siet[zx]] == 1:
            ex_ar = zx
            tru_posit[sid_siet[zx]] = 2
            break
        in_ar = zx
    return ex_ar

# опис движ вектрора по левой
def ag_arr(in_ar, tru_posit, sid_siet):
    for z in range(4):
        x = 1 // in_ar
        zx = in_ar - 1 + (4 * x)
        if tru_posit[sid_siet[zx]] == 1:
            ex_ar = zx
            tru_posit[sid_siet[zx]] = 2
            break
        in_ar = zx
    return ex_ar

# перв движ в узле
def strt_run_knot():
    pass

# иниц ошибка наличия стартового узла
def err_strt_posit():
    print('ошибка наличия стартового узла')

def strt_loop(x_knot, x_pos, dxpos):
    x_knot += 1
    dxpos.append(x_pos)
    return x_knot, dxpos

def pr_knot(pos, positt):
    for ii in ('south', 'east', 'north', 'west'):
        if positt[ii] != 0:
            if ii == 'south':
                nn_xx, nn_yy = 95, 120
            if ii == 'east':
                nn_xx, nn_yy = 120, 95
            if ii == 'north':
                nn_xx, nn_yy = 95, 70
            if ii == 'west':
                nn_xx, nn_yy = 70, 95
            n_xx = pos[1] * 50
            n_yy = pos[0] * 50
            line_1s = (nn_xx + n_xx, nn_yy + n_yy)
            line_e = (95 + n_xx, 95 + n_yy)
            pygame.draw.line(screen, (255, 255, 255), line_1s, line_e, 1)

def cicl(strt_x, strt_y, matrix):
    for m_x in range(0, strt_x):
        for m_y in range(0, strt_y):
            if matrix[m_x][m_y]:
                positt = matrix[m_x][m_y]
                pos = [m_x, m_y]
                pr(pos, positt)

def pr(pos, positt):
        n_xx = pos[1] * 50
        n_yy = pos[0] * 50
        squr = pygame.Rect(70, 70, 500, 500)
        squ = pygame.Rect(70 + n_xx, 70 + n_yy, 50, 50)
        pygame.draw.rect(screen, (255, 255, 255), squr, 1)
        pygame.draw.rect(screen, (255, 255, 255), squ, 1)
        if positt['func_l'] == 'g_res':
            res = pygame.Rect(80 + n_xx, 85 + n_yy, 30,20)
            line_s = (70 + n_xx, 95 + n_yy)
            line_e = (120 + n_xx, 95 + n_yy)
            pygame.draw.rect(screen, (255, 255, 255), res, 1)
            pygame.draw.line(screen, (255, 255, 255), line_s, line_e , 1)
        if positt['func_l'] == 'v_res':
            res = pygame.Rect(85 + n_xx, 80 + n_yy, 20, 30)
            line_s = (95 + n_xx, 70 + n_yy)
            line_e = (95 + n_xx, 120 + n_yy)
            pygame.draw.rect(screen, (255, 255, 255), res, 1)
            pygame.draw.line(screen, (255, 255, 255), line_s, line_e, 1)
        for i in ('strex', 'knot', 'strknot', 'fncl'):
            if positt['func_l'] == i:
                 pr_knot(pos, positt)

def cicl1(strt_x, strt_y, matrix1):
    for m_x in range(0, strt_x):
        if matrix1[0][m_x]:
            positt = matrix1[0][m_x]
            pos = [0, m_x]
            pr1(pos, positt)

def pr_knot1(pos, positt):
    for ii in ('south', 'east', 'north', 'west'):
        if positt[ii] != 0:
            if ii == 'south':
                nn_xx, nn_yy = 95, 120
            if ii == 'east':
                nn_xx, nn_yy = 120, 95
            if ii == 'north':
                nn_xx, nn_yy = 95, 70
            if ii == 'west':
                nn_xx, nn_yy = 70, 95
            n_xx = pos[1] * 50
            n_yy = -50
            line_1s = (nn_xx + n_xx, nn_yy + n_yy)
            line_e = (95 + n_xx, 95 + n_yy)
            pygame.draw.line(screen, (255, 255, 255), line_1s, line_e, 3)

def pr1(pos, positt):
    n_xx = pos[1] * 50
    n_yy = -50
    squr = pygame.Rect(70, 70, strt_x * 50, -50)
    squ = pygame.Rect(70 + n_xx, 70 + n_yy, 50, 50)
    pygame.draw.rect(screen, (255, 255, 255), squr, 1)
    pygame.draw.rect(screen, (255, 255, 255), squ, 1)
    if positt['func_l'] == 'g_res':
        res = pygame.Rect(80 + n_xx, 85 + n_yy, 30, 20)
        line_s = (70 + n_xx, 95 + n_yy)
        line_e = (120 + n_xx, 95 + n_yy)
        pygame.draw.rect(screen, (255, 255, 255), res, 3)
        pygame.draw.line(screen, (255, 255, 255), line_s, line_e, 3)
    if positt['func_l'] == 'v_res':
        res = pygame.Rect(85 + n_xx, 80 + n_yy, 20, 30)
        line_s = (95 + n_xx, 70 + n_yy)
        line_e = (95 + n_xx, 120 + n_yy)
        pygame.draw.rect(screen, (255, 255, 255), res, 3)
        pygame.draw.line(screen, (255, 255, 255), line_s, line_e, 3)
    for i in ('strex', 'knot', 'strknot', 'fncl'):
        if positt['func_l'] == i:
            pr_knot1(pos, positt)

def don_1(copy_posit, b_pos):
    if b_pos[1] > 21 and b_pos[1] < 69:
        if b_pos[0] > 71 + 15 * 50 and b_pos[0] < 119 + 15 * 50:
            copy_posit = {}
            copy_pos = b_pos
            print(copy_posit)
            print(copy_pos)
        for i in range(0, 15):
            if b_pos[0] > 71 + i * 50 and b_pos[0] < 119 + i * 50:
                copy_posit = matrix1[0][i].copy()
                copy_pos = b_pos
                print(copy_posit)
                print(copy_pos)
    for i in range(0, 16):
        if b_pos[1] > 71 + i *50 and b_pos[1] < 119 + i * 50:
            for ii in range(0, 16):
                if b_pos[0] > 71 + ii * 50 and b_pos[0] < 119 + ii * 50:
                    matrix[i][ii] = copy_posit.copy()
                    #print(copy_posit)
                    print(matrix[ii][i])
                    if matrix[i][ii]:
                        if matrix[i][ii]['func_l'] == 'g_res' or matrix[i][ii]['func_l'] == 'v_res':
                            matrix[i][ii]['resi'] = main()
                            #print(copy_posit)
                            print(matrix[i][ii])

    return copy_posit






def main():
    #screen = pygame.display.set_mode((640, 480))
    font = pygame.font.Font(None, 32)
    #clock = pygame.time.Clock()
    input_box = pygame.Rect(100, 100, 140, 32)
    color_inactive = pygame.Color('lightskyblue3')
    color_active = pygame.Color('dodgerblue2')
    color = color_inactive
    active = False
    text = ''
    done = False

    while not done:
        for event in pygame.event.get():
            # if event.type == pygame.QUIT:
            #     done = True
            if event.type == pygame.MOUSEBUTTONDOWN:
                # If the user clicked on the input_box rect.
                if input_box.collidepoint(event.pos):
                    # Toggle the active variable.
                    active = not active
                else:
                    active = False
                # Change the current color of the input box.
                color = color_active if active else color_inactive
            if event.type == pygame.KEYDOWN:
                if active:
                    if event.key == pygame.K_RETURN:
                        print(text)
                        text1 = text
                        text = ''
                        text2 = int(text1)# + 10
                        print(text2)
                        done = True

                    elif event.key == pygame.K_BACKSPACE:
                        text = text[:-1]
                    else:
                        text += event.unicode

        screen.fill((30, 30, 30))
        # Render the current text.
        txt_surface = font.render(text, True, color)
        txt_surface2 = font.render('', True, color)
        # Resize the box if the text is too long.
        width = max(200, txt_surface.get_width()+10)
        input_box.w = width
        # Blit the text.
        #screen.blit(txt_surface2, (input_box.x + 5, input_box.y + 5))
        screen.blit(txt_surface, (input_box.x+5, input_box.y+5))
        # Blit the input_box rect.
        pygame.draw.rect(screen, color, input_box, 2)

        pygame.display.flip()
        clock.tick(30)

    return text2

# старт
del_k = 1
fill_knots()

cicl(strt_x, strt_y, matrix)
cicl1(strt_x, strt_y, matrix1)
pygame.display.flip()
copy_posit = {}

stapi = 1
while stapi:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                butt = event.button
                b_pos = event.pos
                copy_posit = don_1(copy_posit, b_pos)
            elif event.button == 3:
                print(event.button)
                print(event.pos)
                stapi = 0
        screen.fill((0, 0, 0))
        cicl(strt_x, strt_y, matrix)
        cicl1(strt_x, strt_y, matrix1)
        pygame.display.flip()
        clock.tick(60)
        break


n_x, n_y, nn_x, nn_y, posit1, posit2 = find_strt_knot(strt_x, strt_y)
tru_pos, tru_posit = knot(n_x, n_y, posit1)
ex_ar = ex_strt_arr(tru_posit)
inter120 = tru_pos
pre_pos = inter120
in_ar = in_arr(ex_ar)
last_in_ar, last_pos = ex_knot(ex_ar, in_ar, tru_pos, last_pos)
pre_pos, tru_pos, pre_posit, tru_posit, matrix[pre_pos[0]][pre_pos[1]] = in_knot(pre_pos, tru_pos, last_pos, pre_posit, tru_posit)
tru_posit = in_knot2(pre_posit, tru_posit, sid_siet, in_ar)
matrix[tru_pos[0]][tru_pos[1]] = tru_posit.copy()
tru_pos, tru_posit = knot(nn_x, nn_y, posit2)
ex_ar = ex_strt_arr(tru_posit)
inter120 = tru_pos
pre_pos = inter120
in_ar = in_arr(ex_ar)
last_in_ar, last_pos = ex_knot(ex_ar, in_ar, tru_pos, last_pos)
pre_pos, tru_pos, pre_posit, tru_posit, matrix[pre_pos[0]][pre_pos[1]] = in_knot(pre_pos, tru_pos, last_pos, pre_posit, tru_posit)
tru_posit = in_knot2(pre_posit, tru_posit, sid_siet, in_ar)
matrix[tru_pos[0]][tru_pos[1]] = tru_posit.copy()
n_x, n_y, posit1 = find_strt_knot_m(strt_x, strt_y)
tru_pos, tru_posit = knot(n_x, n_y, posit1)
in_ar = pass_knot_m(tru_posit)
am_ex, b, sign_rep, d, any_posit, sign_frst_knot, scnd_knot_pos = pass_knot(tru_posit, in_ar, sid_siet, sign_frst_knot, tru_pos, scnd_knot_pos)
dxpos = [[0, 0]]
sign_frst_knot = 1
cnt_knot = 0
cnt_knot, dxpos = strt_loop(cnt_knot, tru_pos, dxpos)
frst_knot_pos = tru_pos.copy()
ex_ar = rule_pass(am_ex, d, sign_rep, tru_posit, in_ar, sign_frst_knot)
print(ex_ar)
print(tru_pos)
print(tru_posit)
print(dxpos)
print(frst_knot_pos)
print(scnd_knot_pos)

del_k = 1
while del_k:
    in_ar = in_arr(ex_ar)
    last_in_ar, last_pos = ex_knot(ex_ar, in_ar, tru_pos, last_pos)
    pre_pos, tru_pos, pre_posit, tru_posit, matrix[pre_pos[0]][pre_pos[1]] = in_knot(pre_pos, tru_pos, last_pos, pre_posit, tru_posit)
    tru_posit = in_knot2(pre_posit, tru_posit, sid_siet, in_ar)
    am_ex, b, sign_rep, d, any_posit, sign_frst_knot, scnd_knot_pos = pass_knot(tru_posit, in_ar, sid_siet, sign_frst_knot, tru_pos, scnd_knot_pos)
    if sign_rep == 1:
        tru_posit[sid_siet[in_ar]] = 0
        # удаление полупетли
        print(frst_resit['resi'], scnd_resit['resi'])
        frst_resit['resi'] = (scnd_resit['resi'] * frst_resit['resi']) / (scnd_resit['resi'] + frst_resit['resi'])
        matrix[frst_res[0]][frst_res[1]] = frst_resit.copy()
        del_knot(scnd_knot_pos, frst_knot_pos, dxpos)
        sign_frst_knot = 0
        cnt_resi_s = 0
        cnt_resi_p = 0
        print(frst_resit['resi'])
    if tru_posit['func_l'] == 'g_res' or tru_posit['func_l'] == 'v_res':
        if sign_frst_knot == 1 and cnt_resi_s == 1:
            scnd_resit = tru_posit.copy()
            scnd_res = tru_pos.copy()
            scnd_resit['resi'] = (scnd_resit['resi'] + frst_resit['resi'])
            if frst_resit['func_l'] == 'g_res':
                matrix[frst_res[0]][frst_res[1]] = knot_0101.copy()
            if frst_resit['func_l'] == 'v_res':
                matrix[frst_res[0]][frst_res[1]] = knot_1010.copy()
            matrix[scnd_res[0]][scnd_res[1]] = scnd_resit.copy()
            frst_resit = scnd_resit.copy()
            frst_res = scnd_res.copy()
            cnt_resi_s = 1
        if sign_frst_knot == 1 and cnt_resi_s == 0:
            frst_resit = tru_posit.copy()
            frst_res = tru_pos.copy()
            cnt_resi_s = 1
            cnt_resi_p = 1


        if sign_frst_knot == 2 and cnt_resi_s == 1:
            frst_resit = scnd_resit.copy()
            frst_res = scnd_res.copy()
            scnd_resit = tru_posit.copy()
            scnd_res = tru_pos.copy()
            scnd_resit['resi'] = (scnd_resit['resi'] + frst_resit['resi'])
            if frst_resit['func_l'] == 'g_res':
                matrix[frst_res[0]][frst_res[1]] = knot_0101.copy()
            if frst_resit['func_l'] == 'v_res':
                matrix[frst_res[0]][frst_res[1]] = knot_1010.copy()
            matrix[scnd_res[0]][scnd_res[1]] = scnd_resit.copy()
            frst_resit = scnd_resit.copy()
            frst_res = scnd_res.copy()
            cnt_resi_s = 1
            print(frst_resit['resi'])
        if sign_frst_knot == 2 and cnt_resi_s == 0:
            scnd_resit = tru_posit.copy()
            scnd_res = tru_pos.copy()
            cnt_resi_s = 1
            cnt_resi_p = 2



    if am_ex >= 3:
        if sign_frst_knot == 2:
            cnt_knot = 0
            dxpos_frst = dxpos.copy()
            dxpos = [[0, 0]]
            scnd_knot_pos = tru_pos.copy()
            cnt_resi_s = 0
        if sign_frst_knot == 0:
            cnt_knot = 0
            dxpos_frst = dxpos.copy()
            dxpos = [[0, 0]]
            cnt_resi_s = 0
            cnt_resi_p = 0
            for iii in ('south', 'east', 'north', 'west'):
                if matrix[scnd_knot_pos[0]][scnd_knot_pos[1]][iii] == 2:
                    matrix[scnd_knot_pos[0]][scnd_knot_pos[1]][iii] = 1
                if matrix[frst_knot_pos[0]][frst_knot_pos[1]][iii] == 2:
                    matrix[frst_knot_pos[0]][frst_knot_pos[1]][iii] = 1
            frst_knot_pos = tru_pos.copy()
            am_ex, b, sign_rep, d, any_posit, sign_frst_knot, scnd_knot_pos = pass_knot(tru_posit, in_ar, sid_siet,
                                                                                        sign_frst_knot, tru_pos,
                                                                                        scnd_knot_pos)
            sign_frst_knot = 1
    cnt_knot, dxpos = strt_loop(cnt_knot, tru_pos, dxpos)
    ex_ar = rule_pass(am_ex, d, sign_rep, tru_posit, in_ar, sign_frst_knot)
    print(ex_ar)
    print(tru_pos)
    print(tru_posit)
    print(dxpos)
    print(frst_knot_pos)
    print(scnd_knot_pos)
    print(frst_resit)
    print(scnd_resit)
    cicl(strt_x, strt_y, matrix)
    screen.fill((0, 0, 0))
    cicl(strt_x, strt_y, matrix)
    pygame.display.flip()
    clock.tick(1)
    kend = 0
    for n_ye in range(0, strt_y):
        for n_xe in range(0, strt_x):
            posite = matrix[n_xe][n_ye]
            if posite:
                if posite['func_l'] == 'v_res' or posite['func_l'] == 'g_res':
                    kend += 1
    if kend == 1:
        del_k = 0

print(matrix)
print(frst_resit['resi'])


while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    pygame.display.flip()
    clock.tick(60)

